define(["require", "exports", "preact/jsx-runtime", "ojs/ojvcomponent", "css!./hello-world-styles.css"], function (require, exports, jsx_runtime_1, ojvcomponent_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.HelloWorld = void 0;
    function HelloWorldImpl({ message = "Hello from  hello-world" }) {
        return (0, jsx_runtime_1.jsx)("p", { children: message });
    }
    exports.HelloWorld = (0, ojvcomponent_1.registerCustomElement)("hello-world", HelloWorldImpl, "HelloWorld", { "properties": { "message": { "type": "string" } } }, { "message": "Hello from  hello-world" });
});
