# ojet virtual component template

## Usage
Refer to the VComponent jsdoc
http://www.oracle.com/webfolder/technetwork/jet/jsdocs/ojvcomponent.html