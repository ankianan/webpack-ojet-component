import { JetElement, JetSettableProperties, JetElementCustomEventStrict, JetSetPropertyType } from 'ojs/index';
import { GlobalProps } from 'ojs/ojvcomponent';
import 'ojs/oj-jsx-interfaces';
import { ExtendGlobalProps } from "ojs/ojvcomponent";
import { ComponentProps, ComponentType } from "preact";
import "css!./hello-world-styles.css";
type Props = Readonly<{
    message?: string;
}>;
declare function HelloWorldImpl({ message }: Props): import("preact").JSX.Element;
export declare const HelloWorld: ComponentType<ExtendGlobalProps<ComponentProps<typeof HelloWorldImpl>>>;
export {};
export interface WorldElement extends JetElement<WorldElementSettableProperties>, WorldElementSettableProperties {
    addEventListener<T extends keyof WorldElementEventMap>(type: T, listener: (this: HTMLElement, ev: WorldElementEventMap[T]) => any, options?: (boolean | AddEventListenerOptions)): void;
    addEventListener(type: string, listener: EventListenerOrEventListenerObject, options?: (boolean | AddEventListenerOptions)): void;
    getProperty<T extends keyof WorldElementSettableProperties>(property: T): WorldElement[T];
    getProperty(property: string): any;
    setProperty<T extends keyof WorldElementSettableProperties>(property: T, value: WorldElementSettableProperties[T]): void;
    setProperty<T extends string>(property: T, value: JetSetPropertyType<T, WorldElementSettableProperties>): void;
    setProperties(properties: WorldElementSettablePropertiesLenient): void;
}
export namespace WorldElement {
    type messageChanged = JetElementCustomEventStrict<WorldElement['message']>;
}
export interface WorldElementEventMap extends HTMLElementEventMap {
    'messageChanged': JetElementCustomEventStrict<WorldElement['message']>;
}
export interface WorldElementSettableProperties extends JetSettableProperties {
    message?: Props['message'];
}
export interface WorldElementSettablePropertiesLenient extends Partial<WorldElementSettableProperties> {
    [key: string]: any;
}
export interface HelloWorldIntrinsicProps extends Partial<Readonly<WorldElementSettableProperties>>, GlobalProps, Pick<preact.JSX.HTMLAttributes, 'ref' | 'key'> {
    onmessageChanged?: (value: WorldElementEventMap['messageChanged']) => void;
}
declare global {
    namespace preact.JSX {
        interface IntrinsicElements {
            'hello-world': HelloWorldIntrinsicProps;
        }
    }
}
