define(["require", "exports", "./hello-world"], function (require, exports, hello_world_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.HelloWorld = void 0;
    Object.defineProperty(exports, "HelloWorld", { enumerable: true, get: function () { return hello_world_1.HelloWorld; } });
});
