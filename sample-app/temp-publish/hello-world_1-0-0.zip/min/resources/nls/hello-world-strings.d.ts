declare const _default: {
    root: {
        "hello-world": {
            sampleString: string;
        };
    };
};
export = _default;
