define(["require", "exports"], function (require, exports) {
    "use strict";
    return {
        "root": {
            "hello-world": {
                "sampleString": "The strings file can be used to manage translatable resources"
            }
        },
    };
});
